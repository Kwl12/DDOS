# ZALLMA DDOSV¹

![Build Status](https://img.shields.io/travis/username/proyek-luar-biasa.svg)
![Coverage](https://img.shields.io/coveralls/username/proyek-luar-biasa.svg)

## Deskripsi
Sc ini untuk ddos website dan sebagai catatan penting kalo mau ddos harus tunggu lumayan lama agar lumayan tembus dan kalo bisa bareng bareng banyak agar tembus juga jangan lupa vpn nya okeh

## Daftar Isi
- [Ddos](#fitur)
- [Langsung masukan url target nanti dan kasih mau berapa detik](#contoh-penggunaan)
- [Kontribusi](#kontribusi)
- [Lisensi](#lisensi)
- [@nandazzz01 - Telegram](#kontak)

## Fitur
- 🔧 Ddos.
- 🚀 Donasi.
- 💡 Exit.

## Instalasi
Ikuti langkah-langkah berikut untuk menginstal dan menjalankan proyek Anda:

1. Install:
   ```bash
   pkg update && pkg upgrade && pkg install nodejs-lts
2. Install:
   ```bash
   pkg install npm
3. Clone repository:
   ```bash
   git clone https://github.com/zallmacodex/zallmaddos
4. Run:
   ```bash
   cd zallmaddos
5. Install:
   ```bash
   npm install chalk axios 
6. Run:
   ```bash
   node index.js
